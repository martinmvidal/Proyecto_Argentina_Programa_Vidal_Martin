package com.vidalmartindeveloper.vmd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VmdApplicationTests {

	@Test
	void contextLoads() {
	}

}
