package com.vidalmartindeveloper.vmd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VmdApplication {

	public static void main(String[] args) {
		SpringApplication.run(VmdApplication.class, args);
	}

}
